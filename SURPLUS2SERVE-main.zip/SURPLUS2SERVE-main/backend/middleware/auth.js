const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "surplus2serve-dev-secret-key-2026";
const FALLBACK_SECRET = "foodrescue-ai-dev-secret";

function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ error: "No token provided" });
  }
  const token = header.split(" ")[1];
  try {
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (err) {
      // Allow seamless transition from legacy dev secret
      decoded = jwt.verify(token, FALLBACK_SECRET);
    }
    req.user = decoded; // { id, role, name }
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Forbidden: insufficient role" });
    }
    next();
  };
}

module.exports = { authenticate, requireRole, JWT_SECRET };
