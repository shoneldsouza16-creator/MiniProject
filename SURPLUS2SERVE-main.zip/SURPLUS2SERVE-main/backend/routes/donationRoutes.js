const express = require("express");
const router = express.Router();
const { authenticate, requireRole } = require("../middleware/auth");
const {
  createDonation,
  listDonations,
  getDonation,
  updateStatus,
  assignVolunteer,
  listDeliveries,
  getRecommendations,
} = require("../controllers/donationController");

router.post("/", authenticate, requireRole("donor"), createDonation);
router.get("/", authenticate, listDonations);

// Volunteer deliveries route (placed before /:id)
router.get("/deliveries/all", authenticate, listDeliveries);

router.get("/:id", authenticate, getDonation);
router.patch("/:id/status", authenticate, updateStatus);
router.post("/:id/assign-volunteer", authenticate, requireRole("volunteer", "admin"), assignVolunteer);
router.get("/:id/recommendations", authenticate, getRecommendations);

module.exports = router;
