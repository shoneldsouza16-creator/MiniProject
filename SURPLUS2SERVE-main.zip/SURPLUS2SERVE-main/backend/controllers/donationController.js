const { v4: uuidv4 } = require("uuid");
const { readData, writeData, getDistanceKm, hoursUntil } = require("../utils/helpers");
const { recommendNgosForDonation } = require("../utils/recommend");

const VALID_STATUSES = [
  "posted",
  "accepted",
  "pickup_pending",
  "in_transit",
  "delivered",
  "completed",
  "cancelled",
  "expired",
  "recovered_circular",
];

// Validated forward-only state transitions
const NEXT_STATUS = {
  posted: ["accepted", "cancelled", "expired", "recovered_circular"],
  accepted: ["pickup_pending", "cancelled", "expired"],
  pickup_pending: ["in_transit", "cancelled"],
  in_transit: ["delivered"],
  delivered: ["completed"],
  completed: [],
  cancelled: [],
  expired: ["recovered_circular"],
  recovered_circular: [],
};

function createDonation(req, res) {
  const { foodType, quantity, servings, prepTime, expiryTime, location, imageUrl, notes } = req.body;

  if (!foodType || !quantity || !servings || !expiryTime || !location) {
    return res.status(400).json({
      error: "foodType, quantity, servings, expiryTime, and location are required",
    });
  }

  const donations = readData("donations");

  const newDonation = {
    id: uuidv4(),
    donorId: req.user.id,
    donorName: req.user.name,
    foodType,
    quantity: Number(quantity),
    servings: Number(servings),
    prepTime: prepTime || null,
    expiryTime,
    location, // { lat, lng, address }
    imageUrl: imageUrl || null,
    notes: notes || "",
    status: "posted",
    recommendations: [],
    acceptedNgoId: null,
    acceptedNgoName: null,
    volunteerId: null,
    volunteerName: null,
    assignedAt: null,
    pickedUpAt: null,
    deliveredAt: null,
    completedAt: null,
    circularRecovery: null,
    createdAt: new Date().toISOString(),
    statusHistory: [{ status: "posted", at: new Date().toISOString(), updatedBy: req.user.name }],
  };

  // Run AI-based explainable recommendation engine
  const ranked = recommendNgosForDonation(newDonation);
  newDonation.recommendations = ranked.slice(0, 5); // top 5 matches

  donations.push(newDonation);
  writeData("donations", donations);

  res.status(201).json({ donation: newDonation });
}

function listDonations(req, res) {
  let donations = readData("donations");
  applyExpiry(donations);

  const { mine, status, nearLat, nearLng, maxDistanceKm } = req.query;

  if (mine === "true") {
    donations = donations.filter((d) => d.donorId === req.user.id);
  }
  if (status) {
    donations = donations.filter((d) => d.status === status);
  }
  if (nearLat && nearLng) {
    const origin = { lat: parseFloat(nearLat), lng: parseFloat(nearLng) };
    donations = donations
      .map((d) => ({ ...d, distanceKm: getDistanceKm(origin, d.location) }))
      .filter((d) => (maxDistanceKm ? d.distanceKm <= parseFloat(maxDistanceKm) : true))
      .sort((a, b) => a.distanceKm - b.distanceKm);
  }

  res.json({ donations });
}

function getDonation(req, res) {
  const donations = readData("donations");
  applyExpiry(donations);
  const donation = donations.find((d) => d.id === req.params.id);
  if (!donation) return res.status(404).json({ error: "Donation not found" });
  res.json({ donation });
}

function updateStatus(req, res) {
  const { status, ngoId, circularRecovery } = req.body;
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: `Invalid status '${status}'. Must be one of: ${VALID_STATUSES.join(", ")}` });
  }

  const donations = readData("donations");
  const donation = donations.find((d) => d.id === req.params.id);
  if (!donation) return res.status(404).json({ error: "Donation not found" });

  const allowedNext = NEXT_STATUS[donation.status] || [];
  const isAdmin = req.user.role === "admin";
  if (!isAdmin && !allowedNext.includes(status)) {
    return res.status(400).json({
      error: `Cannot transition donation from '${donation.status}' to '${status}'. Allowed: [${allowedNext.join(", ")}]`,
    });
  }

  // Authorization checks based on role
  const isOwnerDonor = req.user.role === "donor" && req.user.id === donation.donorId;
  const isNgo = req.user.role === "ngo";
  const isVolunteer = req.user.role === "volunteer";

  if (status === "cancelled") {
    if (!isAdmin && !isOwnerDonor) {
      return res.status(403).json({ error: "Only the donating owner or admin can cancel a donation" });
    }
  } else if (status === "accepted") {
    if (!isAdmin && !isNgo) {
      return res.status(403).json({ error: "Only registered NGOs can accept food donations" });
    }
    const targetNgoId = ngoId || req.user.id;
    const users = readData("users");
    const ngoUser = users.find((u) => u.id === targetNgoId);
    donation.acceptedNgoId = targetNgoId;
    donation.acceptedNgoName = ngoUser ? ngoUser.name : req.user.name;
  } else if (status === "pickup_pending") {
    if (!isAdmin && !isNgo && !isVolunteer) {
      return res.status(403).json({ error: "Only NGO, assigned Volunteer, or Admin can mark pickup pending" });
    }
  } else if (status === "in_transit") {
    if (!isAdmin && !isVolunteer && !isOwnerDonor) {
      return res.status(403).json({ error: "Only Volunteer or Admin can mark donation as in transit" });
    }
    donation.pickedUpAt = new Date().toISOString();
  } else if (status === "delivered") {
    if (!isAdmin && !isVolunteer && !isNgo) {
      return res.status(403).json({ error: "Only Volunteer or Admin can record delivery" });
    }
    donation.deliveredAt = new Date().toISOString();
  } else if (status === "completed") {
    if (!isAdmin && !(isNgo && donation.acceptedNgoId === req.user.id)) {
      return res.status(403).json({ error: "Only the receiving NGO or Admin can confirm completion" });
    }
    donation.completedAt = new Date().toISOString();
  } else if (status === "recovered_circular") {
    // Record circular diversion data
    donation.circularRecovery = {
      pathway: (circularRecovery && circularRecovery.pathway) || "composting", // composting, biogas, animal_feed
      destination: (circularRecovery && circularRecovery.destination) || "Local Composting Facility",
      notes: (circularRecovery && circularRecovery.notes) || "Diverted from landfill",
      divertedAt: new Date().toISOString(),
      wasteKg: donation.quantity,
    };
  }

  donation.status = status;
  donation.statusHistory.push({
    status,
    at: new Date().toISOString(),
    updatedBy: req.user.name,
    role: req.user.role,
  });

  writeData("donations", donations);
  res.json({ donation });
}

// Volunteer claims or accepts a delivery assignment
function assignVolunteer(req, res) {
  const donations = readData("donations");
  const donation = donations.find((d) => d.id === req.params.id);
  if (!donation) return res.status(404).json({ error: "Donation not found" });

  if (!["accepted", "pickup_pending"].includes(donation.status)) {
    return res.status(400).json({ error: `Cannot assign delivery for donation in status '${donation.status}'` });
  }

  donation.volunteerId = req.user.id;
  donation.volunteerName = req.user.name;
  donation.assignedAt = new Date().toISOString();
  donation.status = "pickup_pending";

  donation.statusHistory.push({
    status: "pickup_pending",
    at: new Date().toISOString(),
    updatedBy: req.user.name,
    role: "volunteer",
    note: `Assigned to volunteer ${req.user.name}`,
  });

  writeData("donations", donations);
  res.json({ donation });
}

// Deliveries view for volunteers
function listDeliveries(req, res) {
  const donations = readData("donations");
  const users = readData("users");
  applyExpiry(donations);

  // Available deliveries that need a volunteer
  const available = donations
    .filter((d) => ["accepted", "pickup_pending"].includes(d.status) && !d.volunteerId)
    .map((d) => attachRouteDetails(d, users));

  // Deliveries claimed by this volunteer
  const myDeliveries = donations
    .filter((d) => d.volunteerId === req.user.id)
    .map((d) => attachRouteDetails(d, users));

  res.json({ available, myDeliveries });
}

function attachRouteDetails(donation, users) {
  let ngoLocation = null;
  let ngoName = donation.acceptedNgoName || "Receiving NGO";
  let ngoPhone = "";

  if (donation.acceptedNgoId) {
    const ngo = users.find((u) => u.id === donation.acceptedNgoId);
    if (ngo) {
      ngoLocation = ngo.location;
      ngoName = ngo.name;
      ngoPhone = ngo.phone || "";
    }
  }

  let routeDistanceKm = null;
  if (donation.location && ngoLocation) {
    routeDistanceKm = getDistanceKm(donation.location, ngoLocation);
  }

  return {
    ...donation,
    recipient: {
      name: ngoName,
      location: ngoLocation,
      phone: ngoPhone,
    },
    routeDistanceKm,
  };
}

function getRecommendations(req, res) {
  const donations = readData("donations");
  const donation = donations.find((d) => d.id === req.params.id);
  if (!donation) return res.status(404).json({ error: "Donation not found" });

  const ranked = recommendNgosForDonation(donation);
  res.json({ recommendations: ranked });
}

// Mark any non-final donation whose expiry time has passed as 'expired'
function applyExpiry(donations) {
  let changed = false;
  donations.forEach((d) => {
    if (
      !["completed", "expired", "cancelled", "recovered_circular"].includes(d.status) &&
      hoursUntil(d.expiryTime) <= 0
    ) {
      d.status = "expired";
      d.statusHistory.push({
        status: "expired",
        at: new Date().toISOString(),
        updatedBy: "System (Food Safety Monitor)",
      });
      changed = true;
    }
  });
  if (changed) writeData("donations", donations);
}

module.exports = {
  createDonation,
  listDonations,
  getDonation,
  updateStatus,
  assignVolunteer,
  listDeliveries,
  getRecommendations,
};
