const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { v4: uuidv4 } = require("uuid");
const { readData, writeData } = require("../utils/helpers");
const { JWT_SECRET } = require("../middleware/auth");

function register(req, res) {
  const { name, email, password, role, phone, location } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: "name, email, password, and role are required" });
  }
  if (!["donor", "ngo", "admin", "volunteer"].includes(role)) {
    return res.status(400).json({ error: "role must be donor, ngo, volunteer, or admin" });
  }

  const users = readData("users");
  if (users.find((u) => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: "Email already registered" });
  }

  const passwordHash = bcrypt.hashSync(password, 10);

  const newUser = {
    id: uuidv4(),
    name,
    email,
    passwordHash,
    role,
    phone: phone || "",
    location: location
      ? {
          address: typeof location === "string" ? location : location.address || "City Center",
          lat: location.lat != null && !isNaN(Number(location.lat)) ? Number(location.lat) : 19.076,
          lng: location.lng != null && !isNaN(Number(location.lng)) ? Number(location.lng) : 72.8777,
        }
      : { address: "City Center", lat: 19.076, lng: 72.8777 },
    verified: role === "admin" ? true : false, // donors/NGOs need admin verification
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  writeData("users", users);

  const { passwordHash: _, ...safeUser } = newUser;
  res.status(201).json({ user: safeUser });
}

function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "email and password are required" });
  }

  const users = readData("users");
  const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  const token = jwt.sign(
    { id: user.id, role: user.role, name: user.name },
    JWT_SECRET,
    { expiresIn: "7d" }
  );

  const { passwordHash: _, ...safeUser } = user;
  res.json({ token, user: safeUser });
}

module.exports = { register, login };
