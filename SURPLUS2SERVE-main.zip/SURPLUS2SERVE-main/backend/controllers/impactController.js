const { readData } = require("../utils/helpers");

/**
 * Calculates verified platform impact, strictly separating:
 * 1. Human food redistribution (meals served, kg delivered)
 * 2. Circular non-human recovery (kg diverted to compost/biogas/animal feed)
 * 3. CO2e emissions reduction estimates
 */
function impactSummary(req, res) {
  const donations = readData("donations");

  const completed = donations.filter((d) => d.status === "completed");
  const inProgress = donations.filter((d) => ["accepted", "pickup_pending", "in_transit"].includes(d.status));
  const circularRecovered = donations.filter((d) => d.status === "recovered_circular" || d.circularRecovery != null);

  const totalFoodDonatedKg = donations.reduce((sum, d) => sum + (d.quantity || 0), 0);
  const servingsRedistributed = completed.reduce((sum, d) => sum + (d.servings || 0), 0);
  const kgRedistributed = completed.reduce((sum, d) => sum + (d.quantity || 0), 0);

  const kgCircularDiverted = circularRecovered.reduce((sum, d) => {
    return sum + (d.circularRecovery && d.circularRecovery.wasteKg ? d.circularRecovery.wasteKg : (d.quantity || 0));
  }, 0);

  // Pathways breakdown
  const circularPathways = {
    composting: 0,
    biogas: 0,
    animal_feed: 0,
    other: 0,
  };

  circularRecovered.forEach((d) => {
    const pw = (d.circularRecovery && d.circularRecovery.pathway) || "composting";
    const qty = (d.circularRecovery && d.circularRecovery.wasteKg) || d.quantity || 0;
    if (circularPathways[pw] !== undefined) {
      circularPathways[pw] += qty;
    } else {
      circularPathways.other += qty;
    }
  });

  // Environmental impact estimation (2.5 kg CO2e avoided per kg food diverted from landfill)
  const totalKgDivertedFromLandfill = kgRedistributed + kgCircularDiverted;
  const estimatedCo2eAvoidedKg = Math.round(totalKgDivertedFromLandfill * 2.5 * 10) / 10;

  res.json({
    totalDonations: donations.length,
    donationsCompleted: completed.length,
    activeRescues: inProgress.length,
    servingsRedistributed,
    kgRedistributed,
    kgCircularDiverted,
    totalKgDivertedFromLandfill,
    estimatedCo2eAvoidedKg,
    co2eFactorUsed: "2.5 kg CO2e / kg food waste (EPA/UN FAO model)",
    circularPathways,
    circularRecordsCount: circularRecovered.length,
  });
}

module.exports = { impactSummary };
