const { readData, getDistanceKm, hoursUntil } = require("./helpers");

const URGENCY_SCORE = { high: 3, medium: 2, low: 1 };

/**
 * Recommends the best-matching NGO requirement(s) for a donation.
 * Evaluates:
 * 1. Food safety & remaining distribution window
 * 2. Food category compatibility (exact or 'any')
 * 3. Quantity fulfillment
 * 4. Geodesic distance (Haversine)
 * 5. Recipient urgency and deadline proximity
 * Returns a ranked array with explainable scoring factors.
 */
function recommendNgosForDonation(donation) {
  const requirements = readData("requirements");
  const users = readData("users");

  const hrsLeftDonation = hoursUntil(donation.expiryTime);
  const isSafetyExpired = hrsLeftDonation <= 0;

  const scored = requirements
    .map((req) => {
      const ngo = users.find((u) => u.id === req.ngoId && u.role === "ngo");
      if (!ngo) return null;

      const distanceKm = getDistanceKm(donation.location, req.location);
      if (distanceKm === null) return null;

      const reasons = [];
      let score = 0;

      // 1. Food Safety Gate: expired food cannot be matched for human consumption
      if (isSafetyExpired) {
        return {
          requirement: req,
          ngo: { id: ngo.id, name: ngo.name, location: ngo.location },
          distanceKm,
          score: 0,
          reasons: ["Food is past its safe-use deadline. Routed to Circular Recovery."],
          safetyStatus: "EXPIRED_FOR_CONSUMPTION",
        };
      }

      // 2. Category Match (40 pts)
      const typeMatch =
        req.foodType.toLowerCase() === "any" ||
        req.foodType.toLowerCase() === donation.foodType.toLowerCase();
      if (typeMatch) {
        score += 40;
        reasons.push(
          req.foodType.toLowerCase() === "any"
            ? `Category Flexible: NGO accepts all food types (+40 pts)`
            : `Exact Category Match: '${donation.foodType}' (+40 pts)`
        );
      } else {
        reasons.push(`Category Mismatch: NGO requires '${req.foodType}' vs '${donation.foodType}' (+0 pts)`);
      }

      // 3. Quantity Fit (up to 25 pts)
      if (donation.quantity >= req.requiredQuantity) {
        score += 25;
        reasons.push(
          `Full Demand Met: ${donation.quantity} kg donation covers full ${req.requiredQuantity} kg requirement (+25 pts)`
        );
      } else {
        const partialPts = Math.max(5, Math.round(15 * (donation.quantity / req.requiredQuantity)));
        score += partialPts;
        reasons.push(
          `Partial Coverage: ${donation.quantity} kg of ${req.requiredQuantity} kg requested (+${partialPts} pts)`
        );
      }

      // 4. Distance / Logistics (up to 20 pts)
      const distPoints = Math.max(0, Math.round((20 - distanceKm) * 10) / 10);
      score += distPoints;
      reasons.push(
        distanceKm <= 5
          ? `Local Community: Just ${distanceKm} km away (+${distPoints} pts)`
          : `Distance: ${distanceKm} km away (+${distPoints} pts)`
      );

      // 5. Urgency / Demand Priority (up to 15 pts)
      const urgencyPts = (URGENCY_SCORE[req.urgency] || 1) * 5;
      score += urgencyPts;
      reasons.push(`Urgency Level: ${req.urgency.toUpperCase()} priority requirement (+${urgencyPts} pts)`);

      // 6. Safe Redistribution Window Bonus
      if (hrsLeftDonation > 0 && hrsLeftDonation < 12) {
        score += 10;
        reasons.push(
          `Critical Window: ${Math.round(hrsLeftDonation)}h left before expiry — priority redistribution (+10 pts)`
        );
      } else if (req.deadline) {
        const reqHrsLeft = hoursUntil(req.deadline);
        if (reqHrsLeft > 0 && reqHrsLeft < 24) {
          score += 10;
          reasons.push(`Deadline Proximity: NGO deadline within 24h (+10 pts)`);
        }
      }

      const finalScore = Math.round(score * 10) / 10;

      return {
        requirement: req,
        ngo: { id: ngo.id, name: ngo.name, location: ngo.location },
        distanceKm,
        score: finalScore,
        reasons,
        safetyStatus: hrsLeftDonation < 6 ? "URGENT_WINDOW" : "SAFE",
      };
    })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score);

  return scored;
}

module.exports = { recommendNgosForDonation };
