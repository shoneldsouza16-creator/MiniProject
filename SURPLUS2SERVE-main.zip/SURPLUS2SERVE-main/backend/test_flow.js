const http = require("http");

const BASE_URL = "http://localhost:5000";

async function request(path, { method = "GET", body = null, token = null } = {}) {
  const url = new URL(path, BASE_URL);
  const options = {
    method,
    headers: {
      "Content-Type": "application/json",
    },
  };
  if (token) {
    options.headers["Authorization"] = `Bearer ${token}`;
  }

  return new Promise((resolve, reject) => {
    const req = http.request(url, options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          const parsed = JSON.parse(data || "{}");
          if (res.statusCode >= 400) {
            reject({ status: res.statusCode, data: parsed });
          } else {
            resolve({ status: res.statusCode, data: parsed });
          }
        } catch (e) {
          resolve({ status: res.statusCode, text: data });
        }
      });
    });
    req.on("error", reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function runTests() {
  console.log("=== SURPLUS2SERVE INTEGRATION TESTS ===");

  // 1. Health check
  console.log("\n[Test 1] Health Check...");
  const health = await request("/api/health");
  console.log("Health OK:", health.data.status === "ok");

  const timestamp = Date.now();

  // 2. Register Donor, NGO, Volunteer
  console.log("\n[Test 2] User Registration (4 Roles)...");
  const donorEmail = `donor_${timestamp}@s2s.test`;
  const ngoEmail = `ngo_${timestamp}@s2s.test`;
  const volEmail = `volunteer_${timestamp}@s2s.test`;
  const adminEmail = "admin@test.com"; // using existing admin
  const defaultPwd = "password123";

  const regDonor = await request("/api/auth/register", {
    method: "POST",
    body: {
      name: `Grand Palace Hotel ${timestamp}`,
      email: donorEmail,
      password: defaultPwd,
      role: "donor",
      phone: "9876500001",
      location: { address: "Bandra West, Mumbai", lat: 19.0596, lng: 72.8295 },
    },
  });
  console.log("Donor Registered:", regDonor.data.user.name);

  const regNgo = await request("/api/auth/register", {
    method: "POST",
    body: {
      name: `Annam Community Kitchen ${timestamp}`,
      email: ngoEmail,
      password: defaultPwd,
      role: "ngo",
      phone: "9876500002",
      location: { address: "Dharavi, Mumbai", lat: 19.0402, lng: 72.8509 },
    },
  });
  console.log("NGO Registered:", regNgo.data.user.name);

  const regVol = await request("/api/auth/register", {
    method: "POST",
    body: {
      name: `Rahul Logistics ${timestamp}`,
      email: volEmail,
      password: defaultPwd,
      role: "volunteer",
      phone: "9876500003",
      location: { address: "Bandra East, Mumbai", lat: 19.062, lng: 72.848 },
    },
  });
  console.log("Volunteer Registered:", regVol.data.user.name, "(Role:", regVol.data.user.role + ")");

  // 3. Logins
  console.log("\n[Test 3] User Authentication & Token Issuance...");
  const loginDonor = await request("/api/auth/login", {
    method: "POST",
    body: { email: donorEmail, password: defaultPwd },
  });
  const donorToken = loginDonor.data.token;
  console.log("Donor logged in, token received.");

  const loginNgo = await request("/api/auth/login", {
    method: "POST",
    body: { email: ngoEmail, password: defaultPwd },
  });
  const ngoToken = loginNgo.data.token;
  console.log("NGO logged in, token received.");

  const loginVol = await request("/api/auth/login", {
    method: "POST",
    body: { email: volEmail, password: defaultPwd },
  });
  const volToken = loginVol.data.token;
  console.log("Volunteer logged in, token received.");

  // Admin login
  const loginAdmin = await request("/api/auth/login", {
    method: "POST",
    body: { email: adminEmail, password: "admin" }, // from existing admin
  }).catch(() => null);

  // If password wasn't "admin", test directly with donor/ngo verification or verify role guard
  console.log("\n[Test 4] NGO Posts Food Requirement...");
  const postReq = await request("/api/requirements", {
    method: "POST",
    token: ngoToken,
    body: {
      foodType: "Cooked Rice & Dal",
      requiredQuantity: 20,
      urgency: "high",
      deadline: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      location: { address: "Dharavi Community Center", lat: 19.0402, lng: 72.8509 },
    },
  });
  const reqId = postReq.data.requirement.id;
  console.log("Requirement posted:", postReq.data.requirement.foodType, "Qty:", postReq.data.requirement.requiredQuantity);

  // 5. Donor posts surplus donation
  console.log("\n[Test 5] Donor Posts Surplus Food with AI Recommendations...");
  const postDonation = await request("/api/donations", {
    method: "POST",
    token: donorToken,
    body: {
      foodType: "Cooked Rice & Dal",
      quantity: 25,
      servings: 50,
      prepTime: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
      expiryTime: new Date(Date.now() + 10 * 3600 * 1000).toISOString(), // 10 hrs safe window
      location: { address: "Bandra West, Mumbai", lat: 19.0596, lng: 72.8295 },
      notes: "Freshly prepared banquet surplus, kept warm in insulated boxes",
    },
  });
  const donation = postDonation.data.donation;
  console.log("Donation posted:", donation.foodType, "Status:", donation.status);
  console.log("AI Recommendations generated:", donation.recommendations.length);
  if (donation.recommendations.length > 0) {
    const top = donation.recommendations[0];
    console.log("Top Match:", top.ngo.name, "| Score:", top.score, "| Reasons:", top.reasons);
  }

  // 6. NGO Accepts Donation
  console.log("\n[Test 6] NGO Accepts Surplus Donation...");
  const acceptRes = await request(`/api/donations/${donation.id}/status`, {
    method: "PATCH",
    token: ngoToken,
    body: { status: "accepted", ngoId: regNgo.data.user.id },
  });
  console.log("Donation status after NGO acceptance:", acceptRes.data.donation.status, "| Accepted by:", acceptRes.data.donation.acceptedNgoName);

  // 7. Volunteer Lists Available Deliveries
  console.log("\n[Test 7] Volunteer Queries Available Logistics Dispatches...");
  const deliveriesRes = await request("/api/donations/deliveries/all", {
    token: volToken,
  });
  console.log("Available deliveries for pickup:", deliveriesRes.data.available.length);
  const foundAvailable = deliveriesRes.data.available.find((d) => d.id === donation.id);
  console.log("Donation is available for pickup by volunteer:", !!foundAvailable);
  if (foundAvailable) {
    console.log("Route calculated: Donor to NGO distance is ~" + foundAvailable.routeDistanceKm + " km");
  }

  // 8. Volunteer Claims Assignment
  console.log("\n[Test 8] Volunteer Claims Delivery Assignment...");
  const claimRes = await request(`/api/donations/${donation.id}/assign-volunteer`, {
    method: "POST",
    token: volToken,
  });
  console.log("Assigned Volunteer:", claimRes.data.donation.volunteerName, "| Status:", claimRes.data.donation.status);

  // 9. Volunteer Updates: Pickup Pending -> In Transit
  console.log("\n[Test 9] Volunteer Updates Status: In Transit...");
  const transitRes = await request(`/api/donations/${donation.id}/status`, {
    method: "PATCH",
    token: volToken,
    body: { status: "in_transit" },
  });
  console.log("Status after pickup:", transitRes.data.donation.status, "| Picked up at:", transitRes.data.donation.pickedUpAt);

  // 10. Volunteer Updates: In Transit -> Delivered
  console.log("\n[Test 10] Volunteer Delivers Food to NGO Drop-off...");
  const deliveredRes = await request(`/api/donations/${donation.id}/status`, {
    method: "PATCH",
    token: volToken,
    body: { status: "delivered" },
  });
  console.log("Status after delivery:", deliveredRes.data.donation.status, "| Delivered at:", deliveredRes.data.donation.deliveredAt);

  // 11. NGO Confirms Receipt: Delivered -> Completed
  console.log("\n[Test 11] NGO Confirms Handover Receipt (Completed)...");
  const completedRes = await request(`/api/donations/${donation.id}/status`, {
    method: "PATCH",
    token: ngoToken,
    body: { status: "completed" },
  });
  console.log("Final donation status:", completedRes.data.donation.status, "| Completed at:", completedRes.data.donation.completedAt);

  // 12. Circular Food Recovery Verification
  console.log("\n[Test 12] Circular Food Recovery Workflow (Diverting Spoiled Surplus)...");
  // Create an expired donation
  const postSpoiled = await request("/api/donations", {
    method: "POST",
    token: donorToken,
    body: {
      foodType: "Leftover Cooked Rice (Past 24h)",
      quantity: 12,
      servings: 24,
      prepTime: new Date(Date.now() - 30 * 3600 * 1000).toISOString(),
      expiryTime: new Date(Date.now() - 2 * 3600 * 1000).toISOString(), // Expired 2 hrs ago
      location: { address: "Bandra West, Mumbai", lat: 19.0596, lng: 72.8295 },
    },
  });
  console.log("Created spoiled donation:", postSpoiled.data.donation.foodType, "| Initial status:", postSpoiled.data.donation.status);

  // Route to circular recovery (composting)
  const circularRes = await request(`/api/donations/${postSpoiled.data.donation.id}/status`, {
    method: "PATCH",
    token: donorToken,
    body: {
      status: "recovered_circular",
      circularRecovery: {
        pathway: "composting",
        destination: "Green Soil Bio-Compost Hub",
        notes: "Aerobic microbial decomposition for municipal park enrichment",
      },
    },
  });
  console.log("Circular recovery recorded. Status:", circularRes.data.donation.status, "| Pathway:", circularRes.data.donation.circularRecovery.pathway);

  // 13. Verify Impact Analytics
  console.log("\n[Test 13] Verifying Impact Analytics (Human Redistribution vs Circular Diversion)...");
  const impactRes = await request("/api/impact/summary");
  console.log("Impact Summary:", impactRes.data);

  console.log("\n=== ALL TEST SCENARIOS PASSED SUCCESSFULLY ===");
}

runTests().catch((err) => {
  console.error("Test execution failed:", err);
  process.exit(1);
});
