// If already logged in, skip straight to the dashboard
(function redirectIfLoggedIn() {
  const user = getUser();
  if (user && getToken()) goToDashboard(user.role);
})();

const tabLogin = document.getElementById("tabLogin");
const tabRegister = document.getElementById("tabRegister");
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");

tabLogin.addEventListener("click", () => {
  tabLogin.classList.add("active");
  tabRegister.classList.remove("active");
  loginForm.style.display = "block";
  registerForm.style.display = "none";
});

tabRegister.addEventListener("click", () => {
  tabRegister.classList.add("active");
  tabLogin.classList.remove("active");
  registerForm.style.display = "block";
  loginForm.style.display = "none";
});

// Demo accounts for instant one-click testing
const DEMO_ACCOUNTS = {
  donor: { email: "donor@test.com", password: "password123" },
  ngo: { email: "ngo@test.com", password: "password123" },
  volunteer: { email: "volunteer@test.com", password: "password123" },
  admin: { email: "admin@test.com", password: "admin" },
};

function fillDemoLogin(role) {
  tabLogin.click();
  const acc = DEMO_ACCOUNTS[role];
  if (!acc) return;
  document.getElementById("loginEmail").value = acc.email;
  document.getElementById("loginPassword").value = acc.password;
  document.getElementById("loginMsg").textContent = `Filled ${role.toUpperCase()} credentials. Click 'Sign In' or submit!`;
  document.getElementById("loginMsg").className = "success-msg";
}

document.getElementById("demoDonorBtn")?.addEventListener("click", () => fillDemoLogin("donor"));
document.getElementById("demoNgoBtn")?.addEventListener("click", () => fillDemoLogin("ngo"));
document.getElementById("demoVolBtn")?.addEventListener("click", () => fillDemoLogin("volunteer"));
document.getElementById("demoAdminBtn")?.addEventListener("click", () => fillDemoLogin("admin"));

// Login Submission
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("loginMsg");
  msg.textContent = "";
  try {
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;
    const data = await apiRequest("/auth/login", {
      method: "POST",
      body: { email, password },
      auth: false,
    });
    setSession(data.token, data.user);
    goToDashboard(data.user.role);
  } catch (err) {
    msg.className = "error-msg";
    msg.textContent = err.message;
  }
});

// Registration Submission (Simplified: No manual latitude/longitude inputs)
registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("registerMsg");
  msg.textContent = "";
  try {
    const addressInput = document.getElementById("regAddress");
    const address = addressInput ? addressInput.value.trim() : "City Center";

    const body = {
      role: document.getElementById("regRole").value,
      name: document.getElementById("regName").value.trim(),
      email: document.getElementById("regEmail").value.trim(),
      password: document.getElementById("regPassword").value,
      phone: document.getElementById("regPhone").value.trim(),
      location: {
        address: address,
        lat: 19.0760, // Standard baseline city coordinate
        lng: 72.8777,
      },
    };

    await apiRequest("/auth/register", { method: "POST", body, auth: false });
    msg.className = "success-msg";
    msg.textContent = "Registration successful! You can now log in." +
      (body.role !== "admin" ? " (Account pending verification.)" : "");
    registerForm.reset();
    tabLogin.click();
    document.getElementById("loginEmail").value = body.email;
  } catch (err) {
    msg.className = "error-msg";
    msg.textContent = err.message;
  }
});

// Dynamic Impact Stats loading on landing page
async function loadLandingImpact() {
  try {
    const data = await apiRequest("/impact");
    if (data) {
      const mealsEl = document.getElementById("statMeals");
      const rescuedEl = document.getElementById("statRescued");
      const co2El = document.getElementById("statCo2");
      if (mealsEl && data.servingsRedistributed != null) {
        mealsEl.textContent = `${data.servingsRedistributed} meals`;
      }
      if (rescuedEl && data.totalKgDivertedFromLandfill != null) {
        rescuedEl.textContent = `${data.totalKgDivertedFromLandfill} kg`;
      }
      if (co2El && data.estimatedCo2eAvoidedKg != null) {
        co2El.textContent = `${data.estimatedCo2eAvoidedKg} kg`;
      }
    }
  } catch (e) {
    // Non-blocking fallback
  }
}

loadLandingImpact();
