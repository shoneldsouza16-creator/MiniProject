const user = requireAuth("ngo");
if (user) document.getElementById("userName").textContent = `${user.name} (NGO)`;

document.getElementById("logoutBtn").addEventListener("click", () => {
  clearSession();
  window.location.href = "index.html";
});

// ---- Map preview ----
const defaultCenter = user && user.location && user.location.lat && user.location.lng
  ? [user.location.lat, user.location.lng]
  : [19.076, 72.8777];
const map = L.map("map").setView(defaultCenter, 12);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(map);
let marker = L.marker(defaultCenter).addTo(map);

function updateMapPreview() {
  const lat = parseFloat(document.getElementById("lat").value);
  const lng = parseFloat(document.getElementById("lng").value);
  if (isNaN(lat) || isNaN(lng)) return;
  marker.setLatLng([lat, lng]);
  map.setView([lat, lng], 13);
}
document.getElementById("lat").addEventListener("input", updateMapPreview);
document.getElementById("lng").addEventListener("input", updateMapPreview);

// Pre-fill lat/lng/address from NGO's registered location, if available
if (user && user.location) {
  document.getElementById("lat").value = user.location.lat ?? "";
  document.getElementById("lng").value = user.location.lng ?? "";
  document.getElementById("address").value = user.location.address ?? "";
}

// ---- Post requirement ----
document.getElementById("requirementForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("reqMsg");
  msg.textContent = "";
  try {
    const body = {
      foodType: document.getElementById("foodType").value,
      requiredQuantity: document.getElementById("requiredQuantity").value,
      urgency: document.getElementById("urgency").value,
      deadline: document.getElementById("deadline").value,
      location: {
        address: document.getElementById("address").value,
        lat: parseFloat(document.getElementById("lat").value),
        lng: parseFloat(document.getElementById("lng").value),
      },
    };
    await apiRequest("/requirements", { method: "POST", body });
    msg.className = "success-msg";
    msg.textContent = "Requirement posted! AI matcher updated.";
    e.target.reset();
    loadRequirements();
    loadNearby();
  } catch (err) {
    msg.className = "error-msg";
    msg.textContent = err.message;
  }
});

// ---- My requirements ----
async function loadRequirements() {
  const tbody = document.getElementById("reqTableBody");
  tbody.innerHTML = `<tr><td colspan="5">Loading...</td></tr>`;
  try {
    const { requirements } = await apiRequest("/requirements?mine=true");
    if (!requirements || !requirements.length) {
      tbody.innerHTML = `<tr><td colspan="5">No requirements posted yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = requirements
      .slice()
      .reverse()
      .map(
        (r) => `
      <tr>
        <td><strong>${r.foodType}</strong></td>
        <td>${r.requiredQuantity}</td>
        <td><span class="badge urgency-${r.urgency}">${r.urgency.toUpperCase()}</span></td>
        <td>${r.deadline ? new Date(r.deadline).toLocaleString() : "—"}</td>
        <td><button class="danger" style="padding:4px 8px; font-size:0.8rem;" data-del="${r.id}">Delete</button></td>
      </tr>`
      )
      .join("");

    document.querySelectorAll("[data-del]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Delete this requirement?")) return;
        await apiRequest(`/requirements/${btn.dataset.del}`, { method: "DELETE" });
        loadRequirements();
        loadNearby();
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="5">Error: ${err.message}</td></tr>`;
  }
}

// ---- Nearby donations ----
async function loadNearby() {
  const tbody = document.getElementById("nearbyTableBody");
  tbody.innerHTML = `<tr><td colspan="7">Loading...</td></tr>`;
  try {
    const radius = document.getElementById("radiusInput").value || 30;
    const lat = user.location?.lat;
    const lng = user.location?.lng;
    const query = lat && lng ? `?status=posted&nearLat=${lat}&nearLng=${lng}&maxDistanceKm=${radius}` : `?status=posted`;
    const { donations } = await apiRequest(`/donations${query}`);
    if (!donations || !donations.length) {
      tbody.innerHTML = `<tr><td colspan="7">No available surplus donations in this radius.</td></tr>`;
      return;
    }
    tbody.innerHTML = donations
      .map((d) => {
        const hrsLeft = (new Date(d.expiryTime).getTime() - Date.now()) / (1000 * 3600);
        let expiryDisplay = new Date(d.expiryTime).toLocaleString();
        if (hrsLeft <= 0) {
          expiryDisplay += ` <span class="badge" style="background:#fee2e2; color:#b91c1c;">Expired</span>`;
        } else if (hrsLeft <= 6) {
          expiryDisplay += ` <span class="badge" style="background:#fef3c7; color:#b45309;">Urgent (${Math.round(hrsLeft)}h)</span>`;
        }

        // Check if there is an AI match score targeting this NGO
        let matchExplanation = "Available for rescue";
        if (d.recommendations && d.recommendations.length > 0) {
          const matchForMe = d.recommendations.find((r) => r.ngo && r.ngo.id === user.id);
          if (matchForMe) {
            matchExplanation = `
              <span class="badge" style="background:#dcfce7; color:#166534;">Match Score: ${matchForMe.score}</span>
              <div style="font-size:0.75rem; color:#4b5563; margin-top:2px;">
                ${matchForMe.reasons && matchForMe.reasons[0] ? matchForMe.reasons[0] : ""}
              </div>
            `;
          } else {
            const top = d.recommendations[0];
            matchExplanation = `<span style="font-size:0.8rem; color:#6b7280;">Recommended (Top score: ${top.score})</span>`;
          }
        }

        return `
        <tr>
          <td><strong>${d.foodType}</strong></td>
          <td>${d.quantity}</td>
          <td>${d.servings}</td>
          <td>${d.distanceKm != null ? d.distanceKm + " km" : "—"}</td>
          <td>${expiryDisplay}</td>
          <td>${matchExplanation}</td>
          <td><button class="primary" style="padding:6px 12px; font-size:0.85rem;" data-accept="${d.id}">Accept Donation</button></td>
        </tr>`;
      })
      .join("");

    document.querySelectorAll("[data-accept]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await apiRequest(`/donations/${btn.dataset.accept}/status`, {
            method: "PATCH",
            body: { status: "accepted", ngoId: user.id },
          });
          loadNearby();
          loadAccepted();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7">Error: ${err.message}</td></tr>`;
  }
}

document.getElementById("radiusInput").addEventListener("change", loadNearby);

// ---- My accepted donations (track through pickup -> in_transit -> delivered -> completed) ----
async function loadAccepted() {
  const tbody = document.getElementById("acceptedTableBody");
  tbody.innerHTML = `<tr><td colspan="6">Loading...</td></tr>`;
  try {
    const { donations } = await apiRequest(`/donations`);
    const mine = (donations || []).filter((d) => d.acceptedNgoId === user.id);
    if (!mine.length) {
      tbody.innerHTML = `<tr><td colspan="6">No accepted donations yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = mine
      .slice()
      .reverse()
      .map((d) => {
        let action = "—";
        if (d.status === "accepted") {
          action = `<button data-action="pickup_pending" data-id="${d.id}" style="padding:4px 8px; font-size:0.8rem;">Schedule Pickup</button>`;
        } else if (d.status === "delivered") {
          action = `<button data-action="completed" data-id="${d.id}" class="primary" style="background:#16a34a; padding:6px 12px; font-size:0.85rem;">Confirm Receipt & Complete</button>`;
        }

        let volunteerInfo = '<span style="color:#9ca3af;">Awaiting volunteer</span>';
        if (d.volunteerName) {
          volunteerInfo = `<span>🚚 <strong>${d.volunteerName}</strong></span>`;
        }

        return `
        <tr>
          <td><strong>${d.foodType}</strong></td>
          <td>${d.quantity}</td>
          <td><span class="badge ${d.status}">${formatStatus(d.status)}</span></td>
          <td>${volunteerInfo}</td>
          <td>${new Date(d.expiryTime).toLocaleString()}</td>
          <td>${action}</td>
        </tr>`;
      })
      .join("");

    document.querySelectorAll("[data-action]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await apiRequest(`/donations/${btn.dataset.id}/status`, {
            method: "PATCH",
            body: { status: btn.dataset.action },
          });
          loadAccepted();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6">Error: ${err.message}</td></tr>`;
  }
}

function formatStatus(status) {
  const map = {
    posted: "Posted",
    accepted: "Accepted",
    pickup_pending: "Pickup Pending",
    in_transit: "In Transit",
    delivered: "Delivered",
    completed: "Completed",
    cancelled: "Cancelled",
    expired: "Expired",
    recovered_circular: "Circular Recovery",
  };
  return map[status] || status;
}

loadRequirements();
loadNearby();
loadAccepted();
