const user = requireAuth("volunteer", "admin");

const userNameEl = document.getElementById("userName");
const logoutBtn = document.getElementById("logoutBtn");
const unverifiedBanner = document.getElementById("unverifiedBanner");
const myDeliveriesContainer = document.getElementById("myDeliveriesContainer");
const availableTableBody = document.getElementById("availableTableBody");
const refreshDeliveriesBtn = document.getElementById("refreshDeliveriesBtn");

if (userNameEl && user) {
  userNameEl.textContent = `${user.name} (Volunteer)`;
}

if (user && !user.verified) {
  unverifiedBanner.style.display = "block";
}

logoutBtn.addEventListener("click", () => {
  clearSession();
  window.location.href = "index.html";
});

refreshDeliveriesBtn.addEventListener("click", () => {
  loadDeliveries();
});

// Setup map
const defaultCenter = [19.076, 72.8777]; // Mumbai coordinates as baseline
const map = L.map("volunteerMap").setView(defaultCenter, 12);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(map);

let markersGroup = L.featureGroup().addTo(map);

async function loadDeliveries() {
  try {
    const data = await apiRequest("/donations/deliveries/all");
    renderMyDeliveries(data.myDeliveries || []);
    renderAvailableDeliveries(data.available || []);
    updateMapMarkers(data.myDeliveries || [], data.available || []);
  } catch (err) {
    console.error("Failed to load deliveries:", err);
    myDeliveriesContainer.innerHTML = `<p style="color:#ef4444;">Error loading deliveries: ${err.message}</p>`;
    availableTableBody.innerHTML = `<tr><td colspan="6" style="color:#ef4444; text-align:center;">Failed to load assignments: ${err.message}</td></tr>`;
  }
}

function renderMyDeliveries(deliveries) {
  if (deliveries.length === 0) {
    myDeliveriesContainer.innerHTML = `
      <div style="padding:16px; background:#f9fafb; border-radius:6px; text-align:center; color:#6b7280;">
        No active delivery assignments. Claim an available request below to start delivering!
      </div>
    `;
    return;
  }

  let html = `<div style="display:grid; grid-gap:16px;">`;
  deliveries.forEach((d) => {
    const donorAddr = (d.location && d.location.address) || "Donor Address";
    const ngoAddr = (d.recipient && d.recipient.location && d.recipient.location.address) || "NGO Address";
    const ngoName = (d.recipient && d.recipient.name) || "Recipient NGO";
    const distText = d.routeDistanceKm != null ? `${d.routeDistanceKm} km` : "N/A";

    let actionBtn = "";
    if (d.status === "pickup_pending") {
      actionBtn = `<button class="primary" onclick="updateDeliveryStatus('${d.id}', 'in_transit')">📦 Pick Up Food (Start Transit)</button>`;
    } else if (d.status === "in_transit") {
      actionBtn = `<button class="primary" style="background:#16a34a;" onclick="updateDeliveryStatus('${d.id}', 'delivered')">🤝 Confirm Handover to NGO</button>`;
    } else if (d.status === "delivered") {
      actionBtn = `<span class="badge" style="background:#dbeafe; color:#1e40af;">Delivered (Awaiting NGO Sign-off)</span>`;
    } else if (d.status === "completed") {
      actionBtn = `<span class="badge" style="background:#dcfce7; color:#166534;">Completed ✓</span>`;
    }

    html += `
      <div style="border:1px solid #e5e7eb; border-radius:8px; padding:16px; background:#ffffff;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px;">
          <div>
            <h3 style="margin:0 0 4px 0; font-size:1.1rem; color:#111827;">${d.foodType} (${d.quantity} kg)</h3>
            <span style="font-size:0.85rem; color:#6b7280;">Feeds ~${d.servings} people • Expiry: ${new Date(d.expiryTime).toLocaleString()}</span>
          </div>
          <div>
            <span class="badge status-${d.status}">${formatStatus(d.status)}</span>
          </div>
        </div>
        <div style="display:grid; grid-template-columns: 1fr 1fr; grid-gap:12px; margin:12px 0; font-size:0.9rem; background:#f9fafb; padding:10px; border-radius:6px;">
          <div>
            <strong>📍 Pickup Location:</strong><br />
            ${donorAddr}
          </div>
          <div>
            <strong>🎯 Drop-off (Recipient):</strong><br />
            ${ngoName} — ${ngoAddr}
          </div>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:12px;">
          <span style="font-size:0.85rem; color:#4b5563;">Est. Distance: <strong>${distText}</strong></span>
          <div>${actionBtn}</div>
        </div>
      </div>
    `;
  });
  html += `</div>`;
  myDeliveriesContainer.innerHTML = html;
}

function renderAvailableDeliveries(available) {
  if (available.length === 0) {
    availableTableBody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align:center; color:#6b7280; padding:16px;">
          No pending pickups available right now. Check back as NGOs accept donations!
        </td>
      </tr>
    `;
    return;
  }

  let html = "";
  available.forEach((d) => {
    const donorAddr = (d.location && d.location.address) || "Donor Address";
    const ngoAddr = (d.recipient && d.recipient.location && d.recipient.location.address) || "NGO Address";
    const ngoName = (d.recipient && d.recipient.name) || "Recipient NGO";
    const distText = d.routeDistanceKm != null ? `${d.routeDistanceKm} km` : "N/A";

    html += `
      <tr>
        <td><strong>${d.foodType}</strong></td>
        <td>${d.quantity} kg (${d.servings} srv)</td>
        <td>${donorAddr}</td>
        <td>${ngoName} (${ngoAddr})</td>
        <td>${distText}</td>
        <td>
          <button class="primary" style="padding:6px 12px; font-size:0.85rem;" onclick="claimDelivery('${d.id}')">
            Claim Delivery
          </button>
        </td>
      </tr>
    `;
  });
  availableTableBody.innerHTML = html;
}

function updateMapMarkers(myDeliveries, available) {
  markersGroup.clearLayers();
  const all = [...myDeliveries, ...available];
  if (all.length === 0) return;

  all.forEach((d) => {
    if (d.location && d.location.lat && d.location.lng) {
      const donorMarker = L.marker([d.location.lat, d.location.lng]).bindPopup(
        `<b>Pickup: ${d.foodType}</b><br/>${d.location.address || ""}<br/>Qty: ${d.quantity} kg`
      );
      markersGroup.addLayer(donorMarker);
    }

    if (d.recipient && d.recipient.location && d.recipient.location.lat && d.recipient.location.lng) {
      const ngoMarker = L.circleMarker([d.recipient.location.lat, d.recipient.location.lng], {
        color: "#2563eb",
        fillColor: "#3b82f6",
        fillOpacity: 0.8,
        radius: 8,
      }).bindPopup(`<b>Drop-off: ${d.recipient.name}</b><br/>${d.recipient.location.address || ""}`);
      markersGroup.addLayer(ngoMarker);
    }
  });

  try {
    map.fitBounds(markersGroup.getBounds(), { padding: [30, 30] });
  } catch (e) {
    // Single point fallback
  }
}

async function claimDelivery(id) {
  if (!confirm("Are you sure you want to claim this delivery assignment?")) return;
  try {
    await apiRequest(`/donations/${id}/assign-volunteer`, { method: "POST" });
    alert("Delivery assignment claimed! Please proceed with pickup.");
    loadDeliveries();
  } catch (err) {
    alert(`Failed to claim delivery: ${err.message}`);
  }
}

async function updateDeliveryStatus(id, newStatus) {
  const confirmMsg =
    newStatus === "in_transit"
      ? "Confirm that you have picked up the food from the donor?"
      : "Confirm that you have delivered the food to the recipient NGO?";
  if (!confirm(confirmMsg)) return;

  try {
    await apiRequest(`/donations/${id}/status`, {
      method: "PATCH",
      body: { status: newStatus },
    });
    loadDeliveries();
  } catch (err) {
    alert(`Failed to update status: ${err.message}`);
  }
}

function formatStatus(status) {
  const map = {
    posted: "Posted",
    accepted: "Accepted",
    pickup_pending: "Pickup Pending",
    in_transit: "In Transit",
    delivered: "Delivered",
    completed: "Completed",
    cancelled: "Cancelled",
    expired: "Expired",
    recovered_circular: "Circular Recovery",
  };
  return map[status] || status;
}

// Initial load
loadDeliveries();
