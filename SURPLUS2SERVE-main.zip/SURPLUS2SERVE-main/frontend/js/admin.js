const user = requireAuth("admin");
if (user) document.getElementById("userName").textContent = `${user.name} (Admin)`;

document.getElementById("logoutBtn").addEventListener("click", () => {
  clearSession();
  window.location.href = "index.html";
});

const refreshStatsBtn = document.getElementById("refreshStatsBtn");
if (refreshStatsBtn) {
  refreshStatsBtn.addEventListener("click", () => {
    loadStats();
    loadImpact();
    loadUsers();
    loadDonations();
  });
}

async function loadStats() {
  const grid = document.getElementById("statsGrid");
  try {
    const stats = await apiRequest("/admin/stats");
    grid.innerHTML = `
      ${statBox(stats.totalUsers, "Total Users")}
      ${statBox(stats.totalDonors, "Donors")}
      ${statBox(stats.totalNgos, "NGOs")}
      ${statBox(stats.totalVolunteers || 0, "Volunteers")}
      ${statBox(stats.unverifiedUsers, "Pending Verification", stats.unverifiedUsers > 0 ? "#ef4444" : null)}
      ${statBox(stats.totalDonations, "Total Donations")}
      ${statBox(stats.totalRequirements, "Food Requirements")}
    `;
  } catch (err) {
    grid.innerHTML = `<div class="error-msg">Error: ${err.message}</div>`;
  }
}

async function loadImpact() {
  const grid = document.getElementById("circularImpactGrid");
  try {
    const imp = await apiRequest("/impact/summary");
    grid.innerHTML = `
      ${statBox(imp.servingsRedistributed || 0, "Human Meals Served (Redistributed)", "#166534")}
      ${statBox((imp.kgRedistributed || 0) + " kg", "Food Rescued & Eaten", "#166534")}
      ${statBox((imp.kgCircularDiverted || 0) + " kg", "Diverted to Compost / Biogas", "#047857")}
      ${statBox((imp.estimatedCo2eAvoidedKg || 0) + " kg", "Est. CO₂e Avoided (Landfill)", "#0f766e")}
    `;
  } catch (err) {
    grid.innerHTML = `<div class="error-msg">Error loading impact: ${err.message}</div>`;
  }
}

function statBox(num, label, color) {
  const style = color ? `style="color:${color};"` : "";
  return `<div class="stat-box"><div class="num" ${style}>${num}</div><div class="label">${label}</div></div>`;
}

async function loadUsers() {
  const tbody = document.getElementById("usersTableBody");
  tbody.innerHTML = `<tr><td colspan="6">Loading...</td></tr>`;
  try {
    const { users } = await apiRequest("/admin/users");
    tbody.innerHTML = users
      .map((u) => {
        const addr = (u.location && u.location.address) || "—";
        const roleBadge = `<span class="badge" style="background:#f3f4f6; color:#374151;">${u.role.toUpperCase()}</span>`;
        const verifyBtn = !u.verified
          ? `<button class="primary" style="padding:4px 8px; font-size:0.8rem;" data-verify="${u.id}">Verify</button>`
          : `<span style="color:#16a34a; font-weight:600; font-size:0.85rem;">Verified ✓</span>`;

        return `
        <tr>
          <td><strong>${u.name}</strong></td>
          <td>${u.email}</td>
          <td>${roleBadge}</td>
          <td>${addr}</td>
          <td>${u.verified ? "✅ Approved" : "⏳ Pending"}</td>
          <td>
            ${!u.verified ? verifyBtn : ""}
            <button class="danger" style="padding:4px 8px; font-size:0.8rem; margin-left:4px;" data-deluser="${u.id}">Delete</button>
          </td>
        </tr>`;
      })
      .join("");

    document.querySelectorAll("[data-verify]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await apiRequest(`/admin/users/${btn.dataset.verify}/verify`, { method: "PATCH" });
          loadUsers();
          loadStats();
        } catch (err) {
          alert(err.message);
        }
      });
    });

    document.querySelectorAll("[data-deluser]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Are you sure you want to delete this user?")) return;
        try {
          await apiRequest(`/admin/users/${btn.dataset.deluser}`, { method: "DELETE" });
          loadUsers();
          loadStats();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6">Error: ${err.message}</td></tr>`;
  }
}

async function loadDonations() {
  const tbody = document.getElementById("donationsTableBody");
  tbody.innerHTML = `<tr><td colspan="7">Loading...</td></tr>`;
  try {
    const { donations } = await apiRequest("/donations");
    if (!donations || !donations.length) {
      tbody.innerHTML = `<tr><td colspan="7">No donations on platform yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = donations
      .slice()
      .reverse()
      .map((d) => {
        let volunteerCol = d.volunteerName ? `🚚 ${d.volunteerName}` : "—";
        let recoveryBtn = "—";

        if (d.status === "expired" || (d.status === "posted" && hoursUntilExpiry(d.expiryTime) <= 0)) {
          recoveryBtn = `<button class="secondary" style="padding:4px 8px; font-size:0.8rem; color:#047857;" onclick="divertCircular('${d.id}')">♻️ Route to Compost</button>`;
        } else if (d.status === "recovered_circular") {
          recoveryBtn = `<span class="badge" style="background:#d1fae5; color:#065f46;">Recovered (${d.circularRecovery?.pathway || "compost"})</span>`;
        }

        return `
        <tr>
          <td><strong>${d.foodType}</strong></td>
          <td>${d.quantity}</td>
          <td>${d.servings}</td>
          <td><span class="badge ${d.status}">${formatStatus(d.status)}</span></td>
          <td>${volunteerCol}</td>
          <td>${new Date(d.expiryTime).toLocaleString()}</td>
          <td>${recoveryBtn}</td>
        </tr>`;
      })
      .join("");
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7">Error: ${err.message}</td></tr>`;
  }
}

window.divertCircular = async function (id) {
  const pathway = prompt("Enter Circular Recovery Pathway:\n1. composting\n2. biogas\n3. animal_feed", "composting");
  if (!pathway) return;

  try {
    await apiRequest(`/donations/${id}/status`, {
      method: "PATCH",
      body: {
        status: "recovered_circular",
        circularRecovery: {
          pathway: pathway.trim().toLowerCase(),
          destination: "Regional Bio-Recovery Facility",
          notes: "Food past safe distribution deadline diverted from municipal landfill",
        },
      },
    });
    alert("Donation successfully diverted to circular recovery!");
    loadDonations();
    loadImpact();
    loadStats();
  } catch (err) {
    alert(`Error: ${err.message}`);
  }
};

function hoursUntilExpiry(dateStr) {
  return (new Date(dateStr).getTime() - Date.now()) / (1000 * 3600);
}

function formatStatus(status) {
  const map = {
    posted: "Posted",
    accepted: "Accepted",
    pickup_pending: "Pickup Pending",
    in_transit: "In Transit",
    delivered: "Delivered",
    completed: "Completed",
    cancelled: "Cancelled",
    expired: "Expired",
    recovered_circular: "Circular Recovery",
  };
  return map[status] || status;
}

loadStats();
loadImpact();
loadUsers();
loadDonations();
