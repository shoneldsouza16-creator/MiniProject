const user = requireAuth("donor");
if (user) document.getElementById("userName").textContent = user.name;

document.getElementById("logoutBtn").addEventListener("click", () => {
  clearSession();
  window.location.href = "index.html";
});

const refreshBtn = document.getElementById("refreshBtn");
if (refreshBtn) {
  refreshBtn.addEventListener("click", () => loadDonations());
}

// ---- Map preview ----
const map = L.map("map").setView([19.0596, 72.8295], 12);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(map);
let marker = L.marker([19.0596, 72.8295]).addTo(map);

function updateMapPreview() {
  const lat = parseFloat(document.getElementById("lat").value);
  const lng = parseFloat(document.getElementById("lng").value);
  if (isNaN(lat) || isNaN(lng)) return;
  if (marker) marker.setLatLng([lat, lng]);
  else marker = L.marker([lat, lng]).addTo(map);
  map.setView([lat, lng], 13);
}
document.getElementById("lat").addEventListener("input", updateMapPreview);
document.getElementById("lng").addEventListener("input", updateMapPreview);

// Geolocation Auto-fill
document.getElementById("autoLocBtn")?.addEventListener("click", () => {
  if (!navigator.geolocation) {
    alert("Geolocation is not supported by your browser.");
    return;
  }
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const lat = parseFloat(pos.coords.latitude.toFixed(4));
      const lng = parseFloat(pos.coords.longitude.toFixed(4));
      document.getElementById("lat").value = lat;
      document.getElementById("lng").value = lng;
      updateMapPreview();
      alert(`Location updated to GPS coordinates: [${lat}, ${lng}]`);
    },
    (err) => {
      alert(`Could not retrieve GPS location: ${err.message}`);
    }
  );
});

// Quick Action Filter State
let currentFilter = "all";
const filterAllBtn = document.getElementById("filterAllBtn");
const filterActiveBtn = document.getElementById("filterActiveBtn");
const filterTransitBtn = document.getElementById("filterTransitBtn");

function setActiveFilter(filterName, activeBtn) {
  currentFilter = filterName;
  [filterAllBtn, filterActiveBtn, filterTransitBtn].forEach((btn) => btn?.classList.remove("active"));
  activeBtn?.classList.add("active");
  loadDonations();
}

filterAllBtn?.addEventListener("click", () => setActiveFilter("all", filterAllBtn));
filterActiveBtn?.addEventListener("click", () => setActiveFilter("active", filterActiveBtn));
filterTransitBtn?.addEventListener("click", () => setActiveFilter("transit", filterTransitBtn));

// ---- Post donation ----
document.getElementById("donationForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("donationMsg");
  msg.textContent = "";
  try {
    const latVal = parseFloat(document.getElementById("lat").value) || 19.076;
    const lngVal = parseFloat(document.getElementById("lng").value) || 72.8777;

    const body = {
      foodType: document.getElementById("foodType").value,
      quantity: document.getElementById("quantity").value,
      servings: document.getElementById("servings").value,
      prepTime: document.getElementById("prepTime").value || null,
      expiryTime: document.getElementById("expiryTime").value,
      notes: document.getElementById("notes").value || "",
      location: {
        address: document.getElementById("address").value,
        lat: latVal,
        lng: lngVal,
      },
    };
    await apiRequest("/donations", { method: "POST", body });
    msg.className = "success-msg";
    msg.textContent = "Donation published! AI has evaluated safe distribution & NGO matches.";
    e.target.reset();
    loadDonations();
  } catch (err) {
    msg.className = "error-msg";
    msg.textContent = err.message;
  }
});

// ---- List my donations ----
async function loadDonations() {
  const tbody = document.getElementById("donationsTableBody");
  tbody.innerHTML = `<tr><td colspan="8">Loading donations...</td></tr>`;
  try {
    const { donations } = await apiRequest("/donations?mine=true");
    if (!donations || !donations.length) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:20px; color:#64748b;">No donations posted yet. Use the form above to post surplus food!</td></tr>`;
      return;
    }

    let filtered = donations.slice().reverse();
    if (currentFilter === "active") {
      filtered = filtered.filter((d) => ["posted", "accepted", "pickup_pending"].includes(d.status));
    } else if (currentFilter === "transit") {
      filtered = filtered.filter((d) => d.status === "in_transit");
    }

    if (!filtered.length) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:20px; color:#64748b;">No donations matching current filter (${currentFilter}).</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered
      .map((d) => {
        const topRec = d.recommendations && d.recommendations[0];
        let recHtml = "—";
        if (topRec) {
          const reasonList = (topRec.reasons || []).map((r) => `• ${r}`).join("\n");
          recHtml = `
            <div>
              <strong>${topRec.ngo.name}</strong> 
              <span class="badge" style="background:#e0f2fe; color:#0369a1;">Score: ${topRec.score}</span>
              <div style="font-size:0.75rem; color:#475569; margin-top:2px;" title="${reasonList}">
                ${topRec.reasons && topRec.reasons[0] ? topRec.reasons[0] : ""}
              </div>
            </div>
          `;
        }

        let logisticsHtml = '<span style="color:#94a3b8;">Unassigned</span>';
        if (d.volunteerName) {
          logisticsHtml = `<span>🚚 <strong>${d.volunteerName}</strong></span>`;
        } else if (["accepted", "pickup_pending"].includes(d.status)) {
          logisticsHtml = '<span style="color:#d97706; font-size:0.85rem; font-weight:600;">⚡ Awaiting Volunteer</span>';
        }

        const hrsLeft = (new Date(d.expiryTime).getTime() - Date.now()) / (1000 * 3600);
        let expiryDisplay = new Date(d.expiryTime).toLocaleString();
        if (hrsLeft <= 0) {
          expiryDisplay += ` <span class="badge expired">Expired</span>`;
        } else if (hrsLeft <= 6) {
          expiryDisplay += ` <span class="badge" style="background:#fef3c7; color:#b45309;">Urgent (${Math.round(hrsLeft)}h)</span>`;
        }

        const actionBtns = renderActionButtons(d);

        return `
        <tr>
          <td><strong>${d.foodType}</strong></td>
          <td>${d.quantity}</td>
          <td>${d.servings}</td>
          <td><span class="badge ${d.status}">${formatStatus(d.status)}</span></td>
          <td>${expiryDisplay}</td>
          <td>${recHtml}</td>
          <td>${logisticsHtml}</td>
          <td>${actionBtns}</td>
        </tr>`;
      })
      .join("");

    // Wire action buttons
    document.querySelectorAll("[data-action]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const action = btn.dataset.action;
        if (action === "cancelled" && !confirm("Are you sure you want to cancel this surplus donation?")) {
          return;
        }
        try {
          await apiRequest(`/donations/${btn.dataset.id}/status`, {
            method: "PATCH",
            body: { status: action },
          });
          loadDonations();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8">Error loading donations: ${err.message}</td></tr>`;
  }
}

function renderActionButtons(d) {
  let btns = [];
  if (d.status === "accepted") {
    btns.push(`<button data-action="pickup_pending" data-id="${d.id}" style="padding:5px 10px; font-size:0.8rem;">Ready for Pickup</button>`);
  }
  if (["posted", "accepted"].includes(d.status)) {
    btns.push(`<button data-action="cancelled" data-id="${d.id}" class="secondary" style="padding:5px 10px; font-size:0.8rem; color:#dc2626; border-color:#fca5a5;">Cancel</button>`);
  }
  return btns.join(" ") || "—";
}

function formatStatus(status) {
  const map = {
    posted: "Posted",
    accepted: "Accepted",
    pickup_pending: "Pickup Pending",
    in_transit: "In Transit",
    delivered: "Delivered",
    completed: "Completed",
    cancelled: "Cancelled",
    expired: "Expired",
    recovered_circular: "Circular Recovery",
  };
  return map[status] || status;
}

loadDonations();
